<?php

    session_start();
    if($_GET['logout']==='true'){
        session_destroy();
        Header('Location: ./index.php');
        exit;
    }
    if($_POST['sjh']){
        include_once('login.php');
    }
    include_once("user.php");
    $name='请登录';
    if($_SESSION['user']) {
        $user = unserialize($_SESSION['user']);
        $name=$user->getName();
    }
?>
