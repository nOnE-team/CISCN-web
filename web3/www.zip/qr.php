<?php
    session_start();
    if(!isset($_SESSION['user'])){
        Header('Location: ./face.php');
        exit;
    }
    if($_FILES['file']['size']>10){
        try {
            require_once('./MGQrCodeReader/MGQrCodeReader.php');//https://github.com/qhxin/qhQrCodeReader
            $image = $_FILES['file']['tmp_name'];
            $MGQrCodeReader = new \MGQrCodeReader\MGQrCodeReader();
            $text=$MGQrCodeReader->read($image);
            if($text===''){
                throw new Exception('QRerror');
            }
            $data = json_decode($text, true);
            if(!$data['id']){
                throw new Exception('JSONerror');
            }
            include_once('user.php');
            include_once('conn.php');
            $user = unserialize($_SESSION['user']);
            $sql="insert into record(p_id, userid)values ('".$data['id']."','".$user->getCardID()."');";
            if(!mysqli_query($conn,$sql)){
                throw new Exception('SQLerror');
            }
        }
        catch (Exception $e){
            die('error');
            //echo $e;
        }
    }
?>
